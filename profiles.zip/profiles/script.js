document.addEventListener("DOMContentLoaded", function() {
    alert("Welcome to Kamohelo Machakela's Profile!");
});
