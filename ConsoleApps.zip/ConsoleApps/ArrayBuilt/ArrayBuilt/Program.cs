﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArrayBuilt
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] dataArray = new int[10] { 76, 44, 65, 22, 87, 88, 33, 44, 25, 70 };
            

            for (int index=0;index<dataArray.Length ;index++ )
            {
                Console.Write(dataArray[index]+" ");
            }
            Console.WriteLine();

            //bubble sort array
            
            int data;
            for (int x=0;x<dataArray.Length ;x++ )
            {
                for (int i = 0; i < dataArray.Length - 1; i++)
                {
                    data = dataArray[i];
                    if (dataArray[i] > dataArray[i + 1])
                    {
                        dataArray[i] = dataArray[i + 1];
                        dataArray[i + 1] = data;
                    }
                }
            }
            //display
            for (int index = 0; index < dataArray.Length; index++)
            {
                Console.Write(dataArray[index] + " ");
            }
            Console.WriteLine();

            //binary algorithm
            int searchValue;
            int lowValue=0;
            int highValue=dataArray.Length-1;
            int middle;
            int foundValue = -1;
            Console.Write("Enter a value: ");
            searchValue = Convert.ToInt32(Console.ReadLine());

            for (int ex=0;ex<dataArray.Length ;ex++ )
            {
                for (int index = 0; index < dataArray.Length; index++)
                {
                    middle = (lowValue + highValue) / 2;
                    if (searchValue == dataArray[middle])
                        foundValue = middle;
                    else if (searchValue > dataArray[middle])
                        lowValue = middle + 1;
                    else
                        highValue = middle - 1;
                }
            }

            if (foundValue != -1)
                Console.WriteLine("Value found at position {0}", foundValue);
            else
                Console.WriteLine("Value not found");
        }//end main
    }//end class
}//end namespace
