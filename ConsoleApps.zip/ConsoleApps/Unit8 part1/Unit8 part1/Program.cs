﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Unit8_part1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Block s1 = new Block(5,6,1,3,9);
            Console.WriteLine(s1.BuiltString());
        }//end main
    }//end classProgram

    public class Point
    {
        private int x;
        private int y;
        private int z;
        public Point() { X = 0; Y = 0; Z = 0; }
        public Point(int x1, int y1, int z1) { X = x1; Y = y1; Z = z1; }
        public int X { get { return x; } set { x = value; } }
        public int Y { get { return y; } set { y = value; } }
        public int Z { get { return z; } set { z = value; } }
        public virtual string BuiltString()
        {
            return "[ " + X + "," + Y + "," + Z + " ] ";
        }
    }//end point

    public class Square : Point
    {
        private int length;

        public Square() : base() { }

        public int SquareData
            {
            set { length = value; }
            get { return length; }
           
            }

        public int Area(int length)
        {
            return this.length = length * length;
        }
            public Square(int x, int y, int z,int length):base(x,y,z)
        {
            this.length = length;
        }
        
        public override string BuiltString()
        {
            return base.BuiltString()+" length: "+length;
        }
    }//end Square

    public class Block:Square
    {
        private int height;

        public Block(int x,int y,int z,int length,int height):base(x,y,z,length)
        {
            this.height = height;
        }

        public override string BuiltString()
        {
            return base.BuiltString()+" height: "+height ;
        }
    
    }//end Block
    



}//end namespace
